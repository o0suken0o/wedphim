﻿document.addEventListener("DOMContentLoaded", () => {
    const infobar = document.getElementById("infobar");
    const breadcrumb = document.getElementById("breadcrumb");
    const playBtn = document.getElementById("playBtn");
    const videoFrame = document.getElementById("videoFrame");

    let VIDEO_LINK = ""; // lưu link video từ API

    // Lấy movieId từ URL
    const params = new URLSearchParams(window.location.search);
    const movieId = params.get("id");

    // Ẩn iframe lúc đầu
    videoFrame.style.display = "none";

    // Gọi API lấy thông tin phim
    fetch(`https://localhost:7019/api/Movies/${movieId}`)
        .then(res => res.json())
        .then(movie => {
            console.log("Movie fetched:", movie);
            if (movie && movie.videoUrl) {
                VIDEO_LINK = movie.videoUrl; // lưu link video
                // Cập nhật breadcrumb
                breadcrumb.innerHTML = '<a href="index.html">Trang chủ</a> / <span>' + movie.title + '</span>';
                infobar.innerHTML = '<span>điểm đánh giá *' + movie.rating + '/ 10</span>';                    ;

            } else {
                console.error("Không tìm thấy movie.videoUrl");
            } 
        })
        .catch(err => console.error(err));

    // Click play mới hiện video
    playBtn.addEventListener("click", () => {
        if (!VIDEO_LINK) return; // nếu chưa có link thì không làm gì
        playBtn.style.display = "none";       // ẩn overlay
        videoFrame.style.display = "block";   // hiện iframe
        videoFrame.src = VIDEO_LINK;          // gán link video
    });
});
