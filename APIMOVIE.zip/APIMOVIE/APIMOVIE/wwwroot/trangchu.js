﻿// =====================
// XỬ LÝ FORM ĐĂNG KÝ
// =====================
document.getElementById('register-form')?.addEventListener('submit', async function (e) {
    e.preventDefault();

    const data = {
        userName: document.getElementById('username').value,
        email: document.getElementById('email').value,
        passWord: document.getElementById('password').value,
    };

    const response = await fetch('https://localhost:7019/api/dangky', {
        method: 'POST',
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data)
    });

    const result = await response.json();

    if (response.ok) {
        document.getElementById('result').innerText = "✅ " + result.message;
        window.location.href = "login.html";
    } else {
        document.getElementById('result').innerText = "❌ " + (result.message || "Đăng ký thất bại!");
    }
});


// =====================
// XỬ LÝ FORM ĐĂNG NHẬP
// =====================
document.getElementById('login-form')?.addEventListener('submit', async function (e) {
    e.preventDefault();

    const data = {
        Email: document.getElementById('login-email').value,
        PassWord: document.getElementById('login-password').value
    };

    const response = await fetch('https://localhost:7019/api/dangnhap', {
        method: 'POST',
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data)
    });

    const result = await response.json();

    if (response.ok) {
        // Lưu tên người dùng vào localStorage để hiển thị ở giao diện chính
        localStorage.setItem("username", result.userName || data.Email);

        // Điều hướng theo quyền
        if (result.role === "Admin") {
            window.location.href = "indexadmin.html";
            

        } else {
            window.location.href = "index.html";

        }
    } else {
        alert(result.message || "Đăng nhập thất bại!");
    }
    
});


// =====================
// HIỂN THỊ TÊN NGƯỜI DÙNG SAU KHI ĐĂNG NHẬP
// =====================

document.addEventListener("DOMContentLoaded", () => {
    const userName = localStorage.getItem("username");
    const loginButton = document.querySelector(".btn-login");
    const logoutButton = document.querySelector(".btn-logout");

    if (userName && loginButton) {
        // 🔹 Thay nút "Đăng nhập" bằng tên người dùng
        loginButton.textContent = userName;
        loginButton.href = "#";

        // 🔹 Hiện nút "Đăng xuất"
        if (logoutButton) {
            logoutButton.style.display = "inline-block";
            logoutButton.onclick = () => {
                if (confirm("Bạn có muốn đăng xuất không?")) {
                    localStorage.removeItem("username");
                    window.location.reload();
                }
            };
        }
    } else {
        // 🔹 Nếu chưa đăng nhập → ẩn nút đăng xuất
        if (logoutButton) logoutButton.style.display = "none";
    }
});


// =====================
// FORM THÊM PHIM (DÙNG CHO ADMIN)
// =====================
document.getElementById('movieForm')?.addEventListener('submit', async function (e) {
    e.preventDefault();

    const data = {
        Title: document.getElementById('Title').value,
        Description: document.getElementById('Description').value,
        Genre: document.getElementById('Genre').value,
        Director: document.getElementById('Director').value,
        Actors: document.getElementById('Actors').value,
        ReleaseDate: document.getElementById('ReleaseDate').value,
        Duration: document.getElementById('Duration').value,
        Language: document.getElementById('Language').value,
        ThumbnailUrl: document.getElementById('ThumbnailUrl').value,
        VideoUrl: document.getElementById('VideoUrl').value,
        Rating: document.getElementById('Rating').value,
        IsActive: document.getElementById('IsActive').checked,
        Country: document.getElementById('Country').value,
        AgeRating: document.getElementById('AgeRating').value
    };

    try {
        const res = await fetch('https://localhost:7019/api/movies/them', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        });

        if (!res.ok) {
            const text = await res.text();
            console.error('❌ Lỗi từ server:', text);
            alert('Lỗi: ' + res.status + ' - ' + text);
            return;
        }

        let result = null;
        try {
            result = await res.json();
        } catch {
            console.warn('⚠️ Phản hồi không phải JSON hợp lệ.');
        }

        console.log('✅ Kết quả:', result);
        alert(result?.message || 'Thêm phim thành công!');

        document.getElementById('movieForm').reset();
        TimeRanges // Xử lý sau khi thêm phim (nếu cần)

        arguments.callee.loadMovies?.();

    } catch (error) {
        console.error('🚨 Lỗi khi gửi request:', error);
        alert('Không thể kết nối tới server.');
    }
    document.getElementById('movieForm').reset();

});
