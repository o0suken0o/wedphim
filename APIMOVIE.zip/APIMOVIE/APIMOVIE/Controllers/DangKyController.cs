﻿using APIMOVIE.Data;
using APIMOVIE.Models;
using Microsoft.AspNetCore.Mvc;

namespace APIMOVIE.Controllers
{
    [Route("api")]
    [ApiController]
    public class DangKyController : ControllerBase
    {
            private readonly MovieDbContext _context;

            public DangKyController(MovieDbContext context)
            {
                _context = context;
            }

            // 🟢 Đăng ký tài khoản mới
            [HttpPost("dangky")]
            public IActionResult DangKy([FromBody] Users registration)
            {
                if (registration == null)
                    return BadRequest(new { message = "Thiếu dữ liệu đăng ký." });

                // 1️⃣ Kiểm tra trùng Email
                bool emailExists = _context.DangKy.Any(u => u.Email == registration.Email);
                if (emailExists)
                    return Conflict(new { message = "Email đã tồn tại!" });

                // 2️⃣ Tạo tài khoản mới (mặc định Role = User)
                registration.Role = "User";
                registration.IsActive = true;

                _context.DangKy.Add(registration);
                _context.SaveChanges();

                return Ok(new { message = "Đăng ký thành công", role = "User" });
            }

            // 🟠 Đăng nhập
            [HttpPost("dangnhap")]
            public IActionResult DangNhap([FromBody] Users login)
            {
                var user = _context.DangKy
                    .FirstOrDefault(u => u.Email == login.Email && u.PassWord == login.PassWord && u.IsActive);

                if (user == null)
                    return Unauthorized(new { message = "Sai tài khoản hoặc mật khẩu" });

                if (user.Role == "Admin")
                    return Ok(new { message = "Đăng nhập thành công (Admin)", role = "Admin" });

                return Ok(new { message = "Đăng nhập thành công (User)", role = "User" });
            }
        }
    }