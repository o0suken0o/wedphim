﻿
document.addEventListener("DOMContentLoaded", async () => {
    const movieGrid = document.getElementById("movie-grid");
    try {
        const res = await fetch("https://localhost:7019/api/movies");
        console.log("Fetch status:", res.status);

        if (!res.ok) throw new Error("Không thể lấy dữ liệu phim!");

        const data = await res.json();
        console.log("Dữ liệu fetch:", data);

        movieGrid.innerHTML = "";
        data.forEach(movie => {
            const card = document.createElement("div");
            card.classList.add("movie-card");
            card.dataset.id = movie.id;
            card.innerHTML = `
        <img class="anh" src="${movie.thumbnailUrl}" alt="${movie.title}">
        <h3>${movie.title}</h3>
        <p>${movie.genre} - ${movie.duration} phút</p>
    `;
            card.addEventListener("click", () => {
                window.location.href = `main.html?id=${movie.id}`;
            });

            movieGrid.appendChild(card);
        });

    } catch (err) {
        console.error(err);
        movieGrid.innerHTML = `<p style="color:red;">Không tải được danh sách phim.</p>`;
    }
});